import pandas as pd
import matplotlib.pyplot as plt

# Load CSV files
df_rankings = pd.read_csv(r"E:\python program\dataset-rankings-1966-2018.csv")
df_matches = pd.read_csv(r"E:\python program\dataset-matches-1966-2018.csv")

# Preprocessing match data
df_matches[['home_team', 'away_team']] = df_matches['teams'].str.split('-', expand=True)
df_matches[['home_goals', 'away_goals']] = df_matches['result'].str.split('-', expand=True)
df_matches['home_goals'] = df_matches['home_goals'].astype(int)
df_matches['away_goals'] = df_matches['away_goals'].astype(int)

# Determine match outcome
def match_outcome(row):
    if row['home_goals'] > row['away_goals']:
        return 'Home Win'
    elif row['home_goals'] < row['away_goals']:
        return 'Away Win'
    else:
        return 'Draw'

df_matches['outcome'] = df_matches.apply(match_outcome, axis=1)

# Aggregate stats
home_stats = df_matches.groupby(['season', 'home_team']).agg(
    wins_home=('outcome', lambda x: (x == 'Home Win').sum()),
    draws_home=('outcome', lambda x: (x == 'Draw').sum()),
    losses_home=('outcome', lambda x: (x == 'Away Win').sum()),
    goals_scored_home=('home_goals', 'sum'),
goals_conceded_home=('away_goals', 'sum'),
    matches_home=('outcome', 'count')
)

away_stats = df_matches.groupby(['season', 'away_team']).agg(
    wins_away=('outcome', lambda x: (x == 'Away Win').sum()),
    draws_away=('outcome', lambda x: (x == 'Draw').sum()),
    losses_away=('outcome', lambda x: (x == 'Home Win').sum()),
    goals_scored_away=('away_goals', 'sum'),
    goals_conceded_away=('home_goals', 'sum'),
    matches_away=('outcome', 'count')
)

# Combine home & away stats
combined_stats = home_stats.add(away_stats, fill_value=0).reset_index()
combined_stats = combined_stats.rename(columns={'home_team': 'team', 'away_team': 'team'})

# Total values
combined_stats['goals_scored'] = combined_stats['goals_scored_home'] + combined_stats['goals_scored_away']

# Merge with rankings
df_combined = pd.merge(
    combined_stats,
    df_rankings,
    how="inner",
    on=["season", "team"]
)

# Extract goals_scored for boxplot
goals_data = df_combined['goals_scored']

# Boxplot for Outlier Detection
plt.figure(figsize=(10, 5))
plt.boxplot(goals_data, patch_artist=True, boxprops=dict(facecolor='steelblue'))

plt.title("Outlier Detection in Goals Scored", fontsize=14)
plt.ylabel("Goals Scored")
plt.grid(False)
plt.tight_layout()
plt.show()
