import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load CSVs
df_matches = pd.read_csv(r"E:\python program\dataset-matches-1966-2018.csv")
df_rankings = pd.read_csv(r"E:\python program\dataset-rankings-1966-2018.csv")

# Parse date properly
df_matches['date'] = pd.to_datetime(df_matches['date'], dayfirst=True, errors='coerce')

# Remove rows with missing or invalid dates
df_matches = df_matches.dropna(subset=['date'])

# Extract goals from result column
df_matches[['home_goals', 'away_goals']] = df_matches['result'].str.split('-', expand=True).astype(int)

# Calculate total goals per match
df_matches['total_goals'] = df_matches['home_goals'] + df_matches['away_goals']

# Set date as index
df_matches = df_matches.set_index('date')

# Resample by day and take mean total goals
daily_goals = df_matches['total_goals'].resample('D').mean()

# Apply rolling 365-day mean
rolling_avg = daily_goals.rolling(window=365, min_periods=30).mean()

# Plotting
plt.figure(figsize=(14, 6))
sns.set(style='whitegrid')
plt.plot(rolling_avg.index, rolling_avg.values, color='red', linewidth=2)

# Title and labels
plt.title('Football Match Goal Trends (365-Day Rolling Average)', fontsize=16)
plt.xlabel('Year', fontsize=12)
plt.ylabel('Avg Total Goals', fontsize=12)
plt.xticks(rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()
