import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load data
df_matches = pd.read_csv(r"E:\python program\dataset-matches-1966-2018.csv")
df_rankings = pd.read_csv(r"E:\python program\dataset-rankings-1966-2018.csv")

# Convert date and fix format
df_matches['date'] = pd.to_datetime(df_matches['date'], dayfirst=True, errors='coerce')

# Split goals from result (e.g., '2-1')
df_matches[['home_goals', 'away_goals']] = df_matches['result'].str.split('-', expand=True).astype(int)
df_matches['total_goals'] = df_matches['home_goals'] + df_matches['away_goals']

# Add Month column for grouping
df_matches['month'] = df_matches['date'].dt.strftime('%b')  # Short month name (e.g., Jan)
df_matches['month_num'] = df_matches['date'].dt.month       # For sorting

# Sort by actual calendar order
df_matches = df_matches.sort_values('month_num')

# Plot Violin Plot using Seaborn
plt.figure(figsize=(12, 6))
sns.violinplot(x='month', y='total_goals', data=df_matches, palette="coolwarm")

plt.title('Distribution of Total Goals Across Months')
plt.xlabel('Month')
plt.ylabel('Total Goals per Match')
plt.grid(True)
plt.tight_layout()
plt.show()
