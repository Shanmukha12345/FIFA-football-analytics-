import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load your data
df_matches = pd.read_csv(r"E:\python program\dataset-matches-1966-2018.csv")

# Fix date parsing (set correct format)
df_matches['date'] = pd.to_datetime(df_matches['date'], dayfirst=True, errors='coerce')

# Ensure numeric goal columns exist and are integers
df_matches[['home_goals', 'away_goals']] = df_matches['result'].str.split('-', expand=True).astype(int)

# Extract year and month
df_matches['year'] = df_matches['date'].dt.year
df_matches['month'] = df_matches['date'].dt.month

# Group by month and year and calculate average home goals
monthly_trend = df_matches.groupby(['year', 'month'])['home_goals'].mean().reset_index()

# Create a formatted date column for plotting
monthly_trend['date'] = pd.to_datetime(monthly_trend[['year', 'month']].assign(day=1))

# Set the style
sns.set(style="darkgrid")

# Plot
plt.figure(figsize=(14, 6))
sns.lineplot(data=monthly_trend, x='date', y='home_goals', color='limegreen')

# Title and labels
plt.title('Average Monthly Home Goals Over Time', fontsize=16)
plt.xlabel('Date', fontsize=12)
plt.ylabel('Average Home Goals', fontsize=12)

# Rotate x-axis labels for better readability
plt.xticks(rotation=45)

# Tight layout
plt.tight_layout()

# Show the plot
plt.show()
