import pandas as pd
import matplotlib.pyplot as plt

# Load data
df_rankings = pd.read_csv(r"E:\python program\dataset-rankings-1966-2018.csv")
df_matches = pd.read_csv(r"E:\python program\dataset-matches-1966-2018.csv")

# Split goals and convert 'date' into datetime
df_matches[['home_goals', 'away_goals']] = df_matches['result'].str.split('-', expand=True).astype(int)
df_matches['total_goals'] = df_matches['home_goals'] + df_matches['away_goals']
df_matches['date'] = pd.to_datetime(df_matches['date'], errors='coerce')
df_matches['year'] = df_matches['date'].dt.year

# Group by year and calculate mean goals
goals_trend = df_matches.groupby('year')['total_goals'].mean().reset_index()

# Plot the line chart
plt.figure(figsize=(12, 6))
plt.plot(goals_trend['year'], goals_trend['total_goals'], color='royalblue', linewidth=2)
plt.fill_between(goals_trend['year'], goals_trend['total_goals'], alpha=0.2, color='skyblue')

plt.title('Interactive Goal Trends Over Years', fontsize=14)
plt.xlabel('Year')
plt.ylabel('Mean Goals per Match')
plt.grid(True)
plt.tight_layout()
plt.show()
